﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using UnityEngine.SceneManagement;
using System.Threading;
using UnityEngine.UI;

[RequireComponent(typeof(Rigidbody))]
public class SnakeComportamento : MonoBehaviour
{
    public Rigidbody rb;

    // Variáveis utilizadas no projeto
    [Tooltip("Velocidade do snake")]
    [Range(0,10)]
    public float velocidadeSnake = 1.0f;

    public float DelayTime = 0.5f;

    public GameObject Body;
    
    private float delayCounter = 0;

    private Vector3 direction = Vector3.right;

    private List<Transform> body = new List<Transform>();

    [Tooltip("Particle system para destruição da maça")]
    public GameObject destruicao;


    [Tooltip("Acesso para o componente Text -> PontosAtual")]
    Text txtPontosAtual;

    
    [Tooltip("Acesso para o componente Text -> PontosMaximo")]
    Text txtPontosMaximo;

    
    [Tooltip("Acesso para o componente Text -> Vidas")]
    Text txtVidas;


    private static int pontosAtual;
    private static int pontosMaximo;
    

    // Start is called before the first frame update
    void Start()
    {
        // Referencia ao Rigidbody
        rb = GetComponent<Rigidbody>(); 

        // Limpa e atualiza o valor do score atual
        pontosAtual = 0;
        txtPontosAtual = GameObject.Find("Canvas/PontosAtual").GetComponent<Text>();
        txtPontosAtual.text= $"Score: {pontosAtual.ToString()}";

        // Atualiza o valor do score máximo
        txtPontosMaximo = GameObject.Find("Canvas/PontosMaximo").GetComponent<Text>();        
        txtPontosMaximo.text= $"High Score: {pontosMaximo.ToString()}"; 

        // Atualiza o valor das vidas da snake
        txtVidas = GameObject.Find("Canvas/Vidas").GetComponent<Text>();        
        txtVidas.text= $"Life: {MenuPrincipal.vidas.ToString()}"; 

    }

    // Update is called once per frame
    void Update()
    {   
        // Retorna se o jogo estiver pausado
        if (MenuPauseComp.pausado){
            return;
        }  

        // Contagem do Tempo 
        delayCounter += Time.deltaTime;

        // Deslocaento da snake        
        if ((Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow)) && (direction != -Vector3.forward)) {            // Para cima
            direction = Vector3.forward;
        } 
        else if((Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))&& (direction != Vector3.forward)) {        // Para baixo
            direction = -Vector3.forward;
        } 
        else if((Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow)) && (direction != -Vector3.right)) {       // Para direita
            direction = Vector3.right;
        }
        else if((Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow)) && (direction != Vector3.right)) {         // Para esquerda
            direction = -Vector3.right;
        }
        
        // Verifica colisão entre a cabeça e o corpo da snake
        if (CheckCollisionBody(direction))
        {   
            // Decrementa a variavel vida
            MenuPrincipal.vidas--;

            // Atualiza o valor das vidas da snake
            txtVidas = GameObject.Find("Canvas/Vidas").GetComponent<Text>();        
            txtVidas.text= $"Life: {MenuPrincipal.vidas.ToString()}";

            Thread.Sleep(2000); 

            // Se não possuir mais vidas, Game Over, então carregar a cena inicial
            if (MenuPrincipal.vidas == 0)
            {
                // Carrega a tela inicial do jogo
                CarregaScene("InitialScene");  
            } 
            else 
            {
                // Carrega a tela inicial do jogo
                CarregaScene("MainScene"); 
            }     
        }


        // Verifica se houve TimeOut e então a snake anda pelo plano
        if (delayCounter > DelayTime) 
        {
            var lastHeadPosition = transform.position;

            transform.forward = direction;
            
            transform.Translate(transform.forward * velocidadeSnake, Space.World);

            if (body.Count > 0) {
                
                var shiftBody = body[body.Count - 1];
                
                body.Remove(shiftBody);
                
                body.Insert(0, shiftBody);
                
                body[body.Count - 1].position = lastHeadPosition;
            }
            
            delayCounter = 0;
        }
    }

    // Verifica se aconteceu uma colisão com a maça
    private void OnTriggerEnter(Collider other) {
        
        if(other.tag.Equals("Apple")) 
        {            
            Destroy(other.gameObject);

            var b = Instantiate(Body);

            if (body.Count > 0) 
            {
                b.transform.position = body[body.Count - 1].position;
            }
            else 
            {
                b.transform.position = transform.position - transform.forward;
            }
            
            body.Add(b.transform);

            
            // Incrementa o valor dos pontos atuais
            pontosAtual += 100;
            txtPontosAtual = GameObject.Find("Canvas/PontosAtual").GetComponent<Text>();
            txtPontosAtual.text= $"Score: {pontosAtual.ToString()}";


            // Atualiza o valor do score máximo
            if (pontosAtual > pontosMaximo) pontosMaximo = pontosAtual;
            txtPontosMaximo = GameObject.Find("Canvas/PontosMaximo").GetComponent<Text>();        
            txtPontosMaximo.text= $"High Score: {pontosMaximo.ToString()}"; 
        }
    }

    // Verifica se houve uma colisão com o corpo da snake
    private bool CheckCollisionBody(Vector3 direction)
    {
        RaycastHit hit;

        if(Physics.Raycast(transform.position, direction, out hit, 1))
        {            
            return hit.transform.tag.Equals("Body");
        }
        else
        {
            return false;
        }
    }


    /// <summary>
    /// Metodo para carregar uma scene
    /// </summary>
    /// <param name="nomeScene">Nome da scene que sera carregada</param>
    public void CarregaScene(string nomeScene)
    { 
        Thread.Sleep(3000);        
        SceneManager.LoadScene(nomeScene);
    }

    public void TouchedObject()
    {

        Debug.Log("Method called via SendMessage");

        if (destruicao != null)
        {
            var particles = Instantiate(destruicao, transform.position, Quaternion.identity);

            Destroy(particles, 1.0f);
        }

        Destroy(this.gameObject);
    }
}
